package com.mirrorx.cast

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                MirrorXHome()
            }
        }
    }
}

@Composable
private fun MirrorXHome() {
    var selected by remember { mutableStateOf("Wi-Fi") }
    var message by remember {
        mutableStateOf("Choose a connection method to get started.")
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))
            Text("MirrorX", fontSize = 34.sp, color = MaterialTheme.colorScheme.primary)
            Text("Phone screen to your TV", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(36.dp))
            Text("Select connection", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(18.dp))

            listOf("Wi-Fi", "USB data", "HDMI").forEach { mode ->
                OutlinedButton(
                    onClick = {
                        selected = mode
                        message = when (mode) {
                            "Wi-Fi" -> "Wi-Fi mode selected. A compatible TV receiver is required."
                            "USB data" -> "USB mode selected. A compatible receiver and data connection are required."
                            else -> "HDMI mode selected. Direct video output depends on phone hardware support."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(mode, fontSize = 18.sp)
                }
                Spacer(Modifier.height(10.dp))
            }

            Spacer(Modifier.height(14.dp))
            Text("Selected: $selected", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.weight(1f))
            Text("MirrorX prototype • v0.1.0", style = MaterialTheme.typography.labelSmall)
        }
    }
}
